from django.contrib import admin
from .models import Subdomain
# Register your models here.

admin.site.register(Subdomain)

